package com.zera.tela

import android.content.Context

object Phrases {
    val all = listOf(
        "O tempo que você não gasta aqui volta para a sua vida.",
        "Seu limite de hoje acabou. O resto do dia é seu.",
        "Levante a cabeça. Tem um mundo inteiro fora dessa tela.",
        "Você combinou isso consigo mesmo. Cumpra.",
        "Mais cinco minutos aqui são cinco minutos a menos de outra coisa.",
        "Respire fundo. Não era urgente.",
        "Ninguém termina o dia pensando: \"queria ter rolado mais o feed\".",
        "Beba água, alongue o corpo, olhe pela janela.",
        "Disciplina é fazer o que você decidiu, mesmo sem vontade.",
        "Seus olhos merecem um intervalo.",
        "Quem manda no seu tempo: você ou o aplicativo?",
        "Pare agora. Amanhã o limite começa zerado.",
        "O que você procura aí provavelmente não está aí.",
        "Uma pausa de verdade vale mais que mais uma rolagem.",
        "Ligue para alguém. Converse de verdade.",
        "Hoje já deu. Escolha algo que deixe você melhor.",
        "Menos tela, mais presença.",
        "Seu futuro agradece cada minuto que você devolve a ele.",
        "Guarde o celular e faça uma coisa só.",
        "Esse limite foi um presente que você deu a si mesmo."
    )

    fun next(c: Context): String {
        val last = Store.lastPhrase(c)
        var i = all.indices.random()
        while (i == last) i = all.indices.random()
        Store.setLastPhrase(c, i)
        return all[i]
    }
}
