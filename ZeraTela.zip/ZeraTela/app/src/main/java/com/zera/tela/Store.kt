package com.zera.tela

import android.content.Context

object Store {
    private fun p(c: Context) = c.getSharedPreferences("zera", Context.MODE_PRIVATE)

    fun limits(c: Context): Map<String, Int> =
        p(c).all
            .filterKeys { it.startsWith("limit_") }
            .mapKeys { it.key.removePrefix("limit_") }
            .mapValues { (it.value as? Int) ?: 0 }

    fun setLimit(c: Context, pkg: String, minutes: Int) {
        p(c).edit().putInt("limit_$pkg", minutes).apply()
    }

    fun remove(c: Context, pkg: String) {
        p(c).edit().remove("limit_$pkg").apply()
    }

    fun lastPhrase(c: Context): Int = p(c).getInt("last_phrase", -1)

    fun setLastPhrase(c: Context, i: Int) {
        p(c).edit().putInt("last_phrase", i).apply()
    }
}
