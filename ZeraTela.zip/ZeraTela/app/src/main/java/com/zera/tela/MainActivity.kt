package com.zera.tela

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var statusUso: TextView
    private lateinit var statusAcc: TextView
    private lateinit var lista: LinearLayout
    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 5000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(28))
        }
        root.addView(tv("Zera Tela", 30f, true))
        root.addView(tv("Limite o tempo diário dos seus apps.", 15f))

        statusUso = tv("", 15f).also { it.setPadding(0, dp(16), 0, 0) }
        statusAcc = tv("", 15f)
        root.addView(statusUso)
        root.addView(statusAcc)

        root.addView(btn("Permitir acesso ao uso") {
            safeStart(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        })
        root.addView(btn("Ativar o bloqueio") {
            safeStart(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(tv("Se a opção estiver cinza (Android 13+): abra as informações do app, menu ⋮ > Permitir configurações restritas.", 13f))
        root.addView(btn("Informações do app") {
            safeStart(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            )
        })
        root.addView(btn("Desativar otimização de bateria") {
            safeStart(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })

        root.addView(tv("Apps com limite", 20f, true).also { it.setPadding(0, dp(24), 0, dp(4)) })
        root.addView(btn("Adicionar apps") { showAddDialog() })
        lista = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(lista)

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    // ---------- UI helpers ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(t: String, size: Float, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = size
        if (bold) setTypeface(null, Typeface.BOLD)
    }

    private fun btn(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t
        setAllCaps(false)
        setOnClickListener { onClick() }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun safeStart(i: Intent) {
        try {
            startActivity(i)
        } catch (e: Exception) {
            toast("Não foi possível abrir essa tela.")
        }
    }

    private fun fmt(min: Int) = if (min >= 60) "${min / 60} h ${min % 60} min" else "$min min"

    private fun accessibilityOn(): Boolean {
        val s = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return s.split(':').any { it.startsWith("$packageName/") && it.endsWith("ZeraService") }
    }

    // ---------- tela principal ----------

    private fun refresh() {
        val uso = hasUsageAccess(this)
        val acc = accessibilityOn()
        statusUso.text = "Acesso ao uso: " + (if (uso) "ativo ✔" else "pendente ✖")
        statusAcc.text = "Bloqueio (acessibilidade): " + (if (acc) "ativo ✔" else "pendente ✖")

        lista.removeAllViews()
        val limits = Store.limits(this)
        if (limits.isEmpty()) {
            lista.addView(tv("Nenhum app adicionado ainda.", 15f))
            return
        }
        val totals: Map<String, Long> =
            if (uso) {
                try {
                    Usage.compute(this).totals
                } catch (e: Exception) {
                    emptyMap()
                }
            } else {
                emptyMap()
            }

        limits.entries
            .map { Triple(it.key, appLabel(this, it.key), it.value) }
            .sortedBy { it.second.lowercase() }
            .forEach { (pkg, label, min) ->
                val usedMin = ((totals[pkg] ?: 0L) / 60_000L).toInt()
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(0, dp(10), 0, dp(10))
                    setOnClickListener { editDialog(pkg, label, min) }
                }
                row.addView(tv(label, 17f, true))
                row.addView(tv("Hoje: ${fmt(usedMin)} de ${fmt(min)}", 14f))
                lista.addView(row)
            }
    }

    // ---------- diálogos ----------

    private fun timeRow(h: Int, m: Int): Triple<LinearLayout, EditText, EditText> {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val eh = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(h.toString())
            setEms(3)
            gravity = Gravity.CENTER
        }
        val em = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(m.toString())
            setEms(3)
            gravity = Gravity.CENTER
        }
        row.addView(eh)
        row.addView(tv(" h   ", 16f))
        row.addView(em)
        row.addView(tv(" min", 16f))
        return Triple(row, eh, em)
    }

    private fun minutesOf(h: EditText, m: EditText): Int =
        (h.text.toString().toIntOrNull() ?: 0) * 60 + (m.text.toString().toIntOrNull() ?: 0)

    @Suppress("DEPRECATION")
    private fun installedApps(): List<Pair<String, String>> {
        val pm = packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
    }

    private fun showAddDialog() {
        val already = Store.limits(this)
        val apps = installedApps().filter { !already.containsKey(it.first) }
        if (apps.isEmpty()) {
            toast("Nenhum app disponível para adicionar.")
            return
        }
        val checks = apps.map { app -> CheckBox(this).apply { text = app.second } }
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            checks.forEach { addView(it) }
        }
        val sv = ScrollView(this).apply { addView(list) }
        val (row, eh, em) = timeRow(1, 0)

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        box.addView(
            sv,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                (resources.displayMetrics.heightPixels * 0.45).toInt()
            )
        )
        box.addView(tv("Limite diário:", 14f).also { it.setPadding(0, dp(12), 0, 0) })
        box.addView(row)

        val dlg = AlertDialog.Builder(this)
            .setTitle("Adicionar apps")
            .setView(box)
            .setPositiveButton("Adicionar", null)
            .setNegativeButton("Cancelar", null)
            .create()
        dlg.show()
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val total = minutesOf(eh, em)
            val chosen = apps.filterIndexed { idx, _ -> checks[idx].isChecked }
            when {
                chosen.isEmpty() -> toast("Marque pelo menos um app.")
                total <= 0 -> toast("Defina um limite maior que zero.")
                else -> {
                    chosen.forEach { Store.setLimit(this, it.first, total) }
                    dlg.dismiss()
                    refresh()
                }
            }
        }
    }

    private fun editDialog(pkg: String, label: String, current: Int) {
        val (row, eh, em) = timeRow(current / 60, current % 60)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), 0)
        }
        box.addView(tv("Limite diário:", 14f))
        box.addView(row)

        val dlg = AlertDialog.Builder(this)
            .setTitle(label)
            .setView(box)
            .setPositiveButton("Salvar", null)
            .setNeutralButton("Remover") { _, _ ->
                Store.remove(this, pkg)
                refresh()
            }
            .setNegativeButton("Cancelar", null)
            .create()
        dlg.show()
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val total = minutesOf(eh, em)
            if (total <= 0) {
                toast("Defina um limite maior que zero.")
            } else {
                Store.setLimit(this, pkg, total)
                dlg.dismiss()
                refresh()
            }
        }
    }
}
