package com.zera.tela

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class ZeraService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var overlay: View? = null
    private val autoClose = Runnable { removeOverlay() }

    private val loop = object : Runnable {
        override fun run() {
            try {
                checkForeground()
            } catch (_: Exception) {
            }
            handler.postDelayed(this, 3000)
        }
    }

    override fun onServiceConnected() {
        handler.removeCallbacks(loop)
        handler.post(loop)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return
        try {
            val limit = Store.limits(this)[pkg] ?: return
            if (!hasUsageAccess(this)) return
            val used = Usage.compute(this).totals[pkg] ?: 0L
            if (used >= limit * 60_000L) block(pkg)
        } catch (_: Exception) {
        }
    }

    private fun checkForeground() {
        val limits = Store.limits(this)
        if (limits.isEmpty() || !hasUsageAccess(this)) return
        val r = Usage.compute(this)
        val fg = r.foreground ?: return
        val limit = limits[fg] ?: return
        if ((r.totals[fg] ?: 0L) >= limit * 60_000L) block(fg)
    }

    private fun block(pkg: String) {
        if (overlay != null) return
        performGlobalAction(GLOBAL_ACTION_HOME)
        showOverlay(appLabel(this, pkg))
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun showOverlay(appName: String) {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(0xF2101010.toInt())
            setPadding(dp(32), dp(32), dp(32), dp(32))
            isClickable = true
        }
        root.addView(TextView(this).apply {
            text = "Limite de $appName atingido"
            textSize = 16f
            setTextColor(0xFFFF8A80.toInt())
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = Phrases.next(this@ZeraService)
            textSize = 26f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setPadding(0, dp(24), 0, dp(32))
        })
        root.addView(Button(this).apply {
            text = "Entendi"
            setAllCaps(false)
            setOnClickListener { removeOverlay() }
        })

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        try {
            wm.addView(root, lp)
            overlay = root
            handler.postDelayed(autoClose, 10_000)
        } catch (_: Exception) {
        }
    }

    private fun removeOverlay() {
        handler.removeCallbacks(autoClose)
        val v = overlay ?: return
        overlay = null
        try {
            (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(v)
        } catch (_: Exception) {
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacks(loop)
        removeOverlay()
        super.onDestroy()
    }
}
