package com.zera.tela

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Process
import java.util.Calendar

@Suppress("DEPRECATION")
fun hasUsageAccess(c: Context): Boolean {
    val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
    val mode = ops.checkOpNoThrow(
        AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName
    )
    return mode == AppOpsManager.MODE_ALLOWED
}

@Suppress("DEPRECATION")
fun appLabel(c: Context, pkg: String): String = try {
    val pm = c.packageManager
    pm.getApplicationInfo(pkg, 0).loadLabel(pm).toString()
} catch (e: Exception) {
    pkg
}

object Usage {
    class Result(val totals: Map<String, Long>, val foreground: String?)

    /** Tempo de uso por pacote desde 00:00 e o app em primeiro plano agora. */
    @Suppress("DEPRECATION")
    fun compute(c: Context): Result {
        val usm = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val now = System.currentTimeMillis()
        val events = usm.queryEvents(cal.timeInMillis, now)
        val e = UsageEvents.Event()
        val totals = HashMap<String, Long>()
        val open = LinkedHashMap<String, Long>()

        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            val pkg = e.packageName ?: continue
            if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) {
                if (!open.containsKey(pkg)) open[pkg] = e.timeStamp
            } else if (e.eventType == UsageEvents.Event.MOVE_TO_BACKGROUND) {
                val s = open.remove(pkg)
                if (s != null) totals[pkg] = (totals[pkg] ?: 0L) + (e.timeStamp - s)
            }
        }

        var fg: String? = null
        for ((pkg, s) in open) {
            totals[pkg] = (totals[pkg] ?: 0L) + (now - s)
            fg = pkg
        }
        return Result(totals, fg)
    }
}
